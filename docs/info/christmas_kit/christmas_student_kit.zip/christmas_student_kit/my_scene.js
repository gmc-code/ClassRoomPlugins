// ============================================================
//  MY CHRISTMAS SCENE
//  This is the only file you need to change.
//  Change the words and numbers. Keep the commas, the brackets
//  and the "speech marks" exactly where they are!
// ============================================================

const sceneTitle = "My Christmas scene";
const sceneBackground = "images/background.png";

// One line for each GIF in your gifs folder.
//   file    = the file name of the GIF (spelt exactly the same)
//   name    = what the picture is called
//   x       = how far across it is (0 = left edge, 100 = right edge)
//   y       = how far down it is   (0 = top edge, 100 = bottom edge)
//   width   = how big it is (10 = one tenth of the width of the background)
//   seconds = how long it plays after a click (number of frames x delay)
//   move    = "right" or "left" makes it travel across the scene (optional).
//             seconds is then how long the whole trip takes.

const myGifs = [
  { file: "example_snowman.gif", name: "Snowman", x: 72, y: 66, width: 15, seconds: 1.2 },
];

// Extras. Change true to false to turn one off.
const letItSnow = true;
const bellSound = true;

// "once" plays the GIF one time for each click.
// "toggle" means click to start and click again to stop.
// "hover" plays while the mouse is over the picture.
const playMode = "once";

const finishMessage = "You found them all. Merry Christmas!";
